package model.collectibles;

public class Supply {

}
